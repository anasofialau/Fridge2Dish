angular.module('app.controllers', ['ionic'])
.controller('food2DishCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])



.controller('Page2Ctrl', function($scope, formData) {
 $scope.user = formData.getForm();

})

   
.controller('myIngredientsCtrl',function ($scope,  $state, $stateParams,formData,Spoonacular) {
  $scope.ingredients = [
    { value: null }
];

$scope.addIngredient= function () {
    $scope.ingredients.push({ value: null });
       console.log($scope.ingredients );

}

$scope.removeIngredient = function (index) {
    $scope.ingredients.splice(index, 1);
}
$scope.find = function (ingredients) {
   console.log(ingredients);
  formData.updateForm(ingredients);
  $state.go('results');

}

})

.service('formData', function() {
 return {
   form: {},
   getForm: function() {
     return this.form;
   },
   updateForm: function(form) {
     this.form = form;
   }
 }
})
.service('recipeData', function(Spoonacular) {
 return {
   recipe: {},
   getRecipe: function() {
     return this.recipe;
   },
   updateRecipe: function(recipeId) {

     this.recipe = recipeId ;
    // console.log(this.recipe);
   }
 }
})

.controller('resultsCtrl', function ($scope,  $state, $stateParams,formData, Spoonacular,recipeData,$localstorage){
$scope.ingredients = formData.getForm();
$scope.recipes =[];
$scope.recipeDetail = function(recipeId){
  recipeData.updateRecipe(recipeId);
  //console.log("test" + recipeData.getRecipe());
 
  //go to details page for this recipe
  $state.go('recipe1');

}
$scope.saveRecentRecipe = function(recipe){
  var key = "recent" + recipe.id;
  $localstorage.setObject(key, recipe);
  console.log("saved " + recipe);

console.log($localstorage.getAllRecents());
}

    //  var selectedIngredients = $scope.ingredients.join('%2C');//$localstorage.getObject('selectedIngredients');
      Spoonacular.getRecipesByIngredients($scope.ingredients).then(function(data){
        console.log("Response: " + JSON.stringify(data));
        $scope.recipes =data;
              // $state.go($state.current, {}, {reload: true});
      });

})


   .controller('allRecipesCtrl',function ($scope, $stateParams) {
})
   
.controller('recipe1Ctrl',
function ($scope, $stateParams, recipeData, Spoonacular,$localstorage,$sce) {
  $scope.recipe = {};





$scope.recipe = Spoonacular.getRecipesByInfoById(recipeData.getRecipe())
.then(function(recipe) {
$scope.recipe = recipe;
$scope.instruction = recipe.instructions;
 
})
.catch(function(err) {
  console.error(err);
})
.finally(function() {
  wrapUpFn();
})

$scope.saveRecipe = function(){
  var key = "recipe" 
  var id = $scope.recipe.id
  key = key + id
  $localstorage.setObject(key, $scope.recipe);
  /*console.log($localstorage.getObject(key));
  console.log("key is= " + key);*/
}

})

.controller('myFavoriteRecipesCtrl', function ($scope,$state, $stateParams, $localstorage,recipeData) {
  console.log($localstorage.getObject("recipe"));
  /*
  code to clear local 
  $window.localStorage.clear();
  $ionicHistory.clearCache();
  $ionicHistory.clearHistory();
*/
$scope.favoriteRecipes = $localstorage.getAllFavorties();
//console.log($localstorage.length());


$scope.deleteFavorite = function(recipeId){
 $localstorage.remove("recipe"+recipeId);
 //$state.reload(); // currently this is a subroute, so refreshing will give 404 not found may be try    $state.go('recipe1');along that line
 console.log("deleted");
}

$scope.recipeDetail = function(recipeId){
  recipeData.updateRecipe(recipeId);
  $state.go('recipe1');
}
})
   

.controller('recentlyUsedRecipesCtrl', function ($scope,$state, $stateParams, $localstorage,recipeData) {
$scope.recentRecipes = $localstorage.getAllRecents();

$scope.recipeDetail = function(recipeId){
  recipeData.updateRecipe(recipeId);
  $state.go('recipe1');
}
$scope.deleteRecent = function(recipeId){
 $localstorage.remove("recent"+recipeId);
 //$state.reload(); // currently this is a subroute, so refreshing will give 404 not found
 console.log("deleted");
}

})
   
.controller('allRecipesSearchCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
 .factory('$localstorage', ['$window', function ($window) {
  return {
    set: function (key, value) {
      $window.localStorage[key] = value;
    },
    get: function (key, defaultValue) {
      return $window.localStorage[key] || defaultValue;
    },
    setObject: function (key, value) {
      $window.localStorage[key] = JSON.stringify(value);
    },
    getObject: function (key) {
      return JSON.parse($window.localStorage[key] || '{}');
    },
    remove: function(key) {
      $window.localStorage.removeItem(key);
    },
    length: function(){
      return $window.localStorage.length;
    },
    getAllFavorties: function(){
        var favorites = [];
        for (var i = 0; i < $window.localStorage.length; i++) {
          var key = $window.localStorage.key(i);
          if(key.includes("recipe"))
        favorites.push(JSON.parse($window.localStorage.getItem(key) || '{}'));
        }
        return favorites;
    }
    ,
    getAllRecents: function(){
        var recents = [];
        for (var i = 0; i < $window.localStorage.length; i++) {
          var key = $window.localStorage.key(i);
          if(key.includes("recent"))
        recents.push(JSON.parse($window.localStorage.getItem(key) || '{}'));
        }
        return recents;
    }


  }
}]);