angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('food2Dish', {
    url: '/page1',
    templateUrl: 'templates/food2Dish.html',
    controller: 'food2DishCtrl'
  })

  .state('myIngredients', {
    url: '/page2',
    templateUrl: 'templates/myIngredients.html',
    controller: 'myIngredientsCtrl'
  })

        .state('results', {
    url: '/page4',
    templateUrl: 'templates/results.html',
    controller: 'resultsCtrl'
  })

  .state('recipe1', {
    url: '/page5',
    templateUrl: 'templates/recipe1.html',
    controller: 'recipe1Ctrl'
  })/*
  .state('recipe2', {
    url: '/page5',
    templateUrl: 'templates/recipe2.html',
    controller: 'recipe2Ctrl'
  })
    .state('recipe3', {
    url: '/page5',
    templateUrl: 'templates/recipe3.html',
    controller: 'recipe3Ctrl'
  })*/
  .state('recipes', {
    url: '/page6',
    templateUrl: 'templates/recipes.html',
    controller: 'recipesCtrl'
  })

        .state('myFavoriteRecipes', {
    url: '/page7',
    templateUrl: 'templates/myFavoriteRecipes.html',
    controller: 'myFavoriteRecipesCtrl'
  })

  .state('allRecipes', {
    url: '/page8',
    templateUrl: 'templates/allRecipes.html',
    controller: 'allRecipesCtrl'
  })

  .state('recentlyUsedRecipes', {
    url: '/page9',
    templateUrl: 'templates/recentlyUsedRecipes.html',
    controller: 'recentlyUsedRecipesCtrl'
  })

  // .state('allRecipesSearch', {
  //   url: '/page10',
  //   templateUrl: 'templates/allRecipesSearch.html',
  //   controller: 'allRecipesSearchCtrl'
  // })

$urlRouterProvider.otherwise('/page1')

  

});