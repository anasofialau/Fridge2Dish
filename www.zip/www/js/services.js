angular.module('app.services', [])

.factory('BlankFactory', [function(){

}])



.service('Spoonacular', function ($http) {
  var baseURL = "https://spoonacular-recipe-food-nutrition-v1.p.mashape.com/";
  //var API_KEY = "N4n8Rr8T0MmshJsPpTftAFlmgjGEp1fJuQzjsnADtsEG9RFJRR";
  var API_KEY = "aNQkktLkW0msh7e4xPht0PeZmS46p1t0Y6bjsnuwgJlGqMSsPC";

  var auth_headers = {
    'X-Mashape-Key': API_KEY,
    'Accept': "application/json"
  };

  return {
      getRecipesByIngredients: function (_ingredients) {
          // ingredients must be encoded like:
          // where number=N is the max number of results to return
          // apples%2Cflour%2Csugar&number=5

          text = "";

          for (i = 0; i < _ingredients.length; i++) { 

          console.log("SEEE"+_ingredients[i].value);
 		   text += _ingredients[i].value + "%2C";
			}
          var settings = {
              method: 'GET',
              url: baseURL + 'recipes/findByIngredients?ingredients=' + text + '&number=10',
              headers: auth_headers,
          };

          console.log("GET:" + JSON.stringify(settings));

          // $http returns a promise, which has a then function,
          // which also returns a promise
          
          return $http(settings)
              .then(function (response) {
                  return response.data;
              });
      },
      searchRecipes: function (_ingredients, _diet, _intolerances) {
          // URLs take the form
          // recipes/search?diet=vegetarian&intolerances=gluten&number=50&query=shrimp%2Ccheese

          // build the URL
          var searchUrl = baseURL + 'recipes/search?';
          var params = [];
          if( _ingredients.length > 0 ){
            _ingredients = _ingredients.join('%2C');
            params.push('query=' + _ingredients);
          } 
          if( _diet.length > 0 ){
            params.push('diet=' + _diet);
          }
          if( _intolerances.length > 0 ){
            params.push('intolerances=' + _intolerances);
          }

          searchUrl = searchUrl + params.join("&") + "&number=50";

          console.log("searchUrl: \n" + searchUrl);

          var settings = {
              method: 'GET',
              url: searchUrl,
              headers: auth_headers,
          };

          console.log("GET:" + JSON.stringify(settings));

          // $http returns a promise, which has a then function,
          // which also returns a promise
          
          return $http(settings)
              .then(function (response) {
                  return response.data;
              });
      },
      getRecipesByInfoById: function (_id) {
          var settings = {
              method: 'GET',
              url: baseURL + 'recipes/' + _id + '/information',
              headers: auth_headers,
          };

          console.log("GET:" + JSON.stringify(settings));

          // $http returns a promise, which has a then function,
          // which also returns a promise
          
          return $http(settings)
              .then(function (response) {
              	console.log(response.data);
                  return response.data;
              });
      },
  }
});